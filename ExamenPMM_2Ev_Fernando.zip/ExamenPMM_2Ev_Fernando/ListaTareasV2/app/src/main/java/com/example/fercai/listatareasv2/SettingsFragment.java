package com.example.fercai.listatareasv2;

import android.os.Bundle;
import android.preference.PreferenceFragment;

/**
 * Created by fercai on 9/02/18.
 */

public class SettingsFragment extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.opciones);
    }
}